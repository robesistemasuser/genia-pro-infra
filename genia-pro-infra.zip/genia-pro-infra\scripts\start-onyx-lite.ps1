param(
  [string]$OnyxPath = "../onyx-local/deployment/docker_compose"
)

$ErrorActionPreference = "Stop"

function Ensure-OnyxComposeCompatibility {
  param(
    [Parameter(Mandatory = $true)]
    [string]$ComposePath
  )

  if (!(Test-Path $ComposePath)) {
    throw "No se encontro docker-compose.yml de Onyx en $ComposePath"
  }

  $content = Get-Content -LiteralPath $ComposePath -Raw
  $updated = $content

  if ($updated -notmatch "HOSTNAME=0\.0\.0\.0") {
    $updated = $updated -replace "(\r?\n\s+environment:\r?\n)(\s+- INTERNAL_URL=)", "`$1      - HOSTNAME=0.0.0.0`r`n`$2"
  }

  $windowsSafeCommand = @"
    command: >
      /bin/sh -c "rm -f /etc/nginx/conf.d/default.conf
      && cp -a /nginx-templates/. /etc/nginx/conf.d/
      && sed 's/\r$//' /etc/nginx/conf.d/run-nginx.sh > /tmp/run-nginx.sh
      && chmod +x /tmp/run-nginx.sh
      && /tmp/run-nginx.sh app.conf.template"
"@

  if ($updated -match "sh /etc/nginx/conf\.d/run-nginx\.sh app\.conf\.template") {
    $updated = $updated -replace "    command: >\r?\n      /bin/sh -c `"rm -f /etc/nginx/conf.d/default.conf\r?\n      && cp -a /nginx-templates/. /etc/nginx/conf.d/\r?\n      && sh /etc/nginx/conf.d/run-nginx.sh app.conf.template`"", $windowsSafeCommand
  }

  if ($updated -ne $content) {
    Set-Content -LiteralPath $ComposePath -Value $updated -NoNewline
    Write-Host "Se aplicaron ajustes de compatibilidad GENIA sobre docker-compose.yml de Onyx."
  }
}

$onyxComposeDir = Resolve-Path $OnyxPath
$envPath = Join-Path $onyxComposeDir.Path ".env"
$templatePath = Join-Path $onyxComposeDir.Path "env.template"
$composePath = Join-Path $onyxComposeDir.Path "docker-compose.yml"

if (!(Test-Path $envPath)) {
  if (Test-Path $templatePath) {
    Copy-Item -LiteralPath $templatePath -Destination $envPath
  } else {
    New-Item -ItemType File -Path $envPath | Out-Null
  }
}

$envContent = Get-Content -LiteralPath $envPath -Raw
if ($envContent -notmatch "(?m)^HOST_PORT=") {
  Add-Content -LiteralPath $envPath -Value "HOST_PORT=8080"
}
if ($envContent -notmatch "(?m)^HOST_PORT_80=") {
  Add-Content -LiteralPath $envPath -Value "HOST_PORT_80=8081"
}

Ensure-OnyxComposeCompatibility -ComposePath $composePath

Push-Location $onyxComposeDir
try {
  docker compose -f docker-compose.yml -f docker-compose.onyx-lite.yml up -d
} finally {
  Pop-Location
}

Write-Host "Onyx Lite levantando:"
Write-Host "- UI/API via nginx: http://localhost:8080"
Write-Host "- Health: http://localhost:8080/nginx-health"
Write-Host ""
Write-Host "Para conectar GENIA backend:"
Write-Host "ONYX_BASE_URL=http://host.docker.internal:8080/api"
