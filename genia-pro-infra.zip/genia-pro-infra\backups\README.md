Backups GENIA PRO
=================

Esta carpeta es para respaldos locales de base de datos.

No subas archivos `.dump`, `.backup` o `.sql` con datos reales a repositorios publicos.

Comandos recomendados:

- Crear backup: `./scripts/backup-postgres.ps1`
- Restaurar backup: `./scripts/restore-postgres.ps1 -BackupFile ./backups/genia_pro_YYYYMMDD_HHMMSS.dump`
