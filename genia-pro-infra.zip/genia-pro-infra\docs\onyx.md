# Integracion opcional Onyx

Onyx se maneja como servicio externo opcional. No forma parte del frontend ni del backend de GENIA.

## Estructura recomendada

```txt
GENIA_PRO/
  genia-pro-frontend/
  genia-pro-backend/
  genia-pro-infra/
  onyx-local/                 # repo externo de Onyx
```

## Por que no crear repo genia-pro-onyx

No conviene crear un fork propio salvo que vayas a modificar codigo fuente de Onyx.

Mejor mantener Onyx como servicio externo:

- se actualiza independiente,
- no contamina el codigo de GENIA,
- puede activarse o apagarse sin afectar la plataforma,
- se documenta desde `genia-pro-infra`.

## Levantar Onyx Lite

Desde `genia-pro-infra`:

```powershell
.\scripts\start-onyx-lite.ps1
```

Esto usa:

```txt
../onyx-local/deployment/docker_compose/docker-compose.yml
../onyx-local/deployment/docker_compose/docker-compose.onyx-lite.yml
```

Y configura puertos para evitar conflicto con GENIA:

- GENIA frontend: `http://localhost:3000`
- GENIA backend: `http://localhost:3001`
- Onyx Lite: `http://localhost:8080`

## Detener Onyx Lite

```powershell
.\scripts\stop-onyx-lite.ps1
```

## Conectar GENIA con Onyx

En `.env` de `genia-pro-infra`:

```env
AI_PROVIDER=onyx
AI_DEFAULT_PROVIDER=onyx
ONYX_BASE_URL=http://host.docker.internal:8080/api
ONYX_API_KEY=
ONYX_PERSONA_ID=
```

Si backend corre fuera de Docker en tu maquina local:

```env
ONYX_BASE_URL=http://localhost:8080/api
```

Si backend y Onyx comparten una red Docker y apuntas directo al servicio interno:

```env
ONYX_BASE_URL=http://api_server:8080/api
```

## Levantar GENIA usando el override Onyx

```powershell
docker compose -f docker-compose.yml -f docker-compose.onyx.yml up -d --build
```

El archivo `docker-compose.onyx.yml` no levanta Onyx; solo configura el backend de GENIA para hablar con Onyx.

Onyx se levanta aparte con `start-onyx-lite.ps1`.

## API key y persona

Dependiendo de la configuracion de Onyx, puedes necesitar:

- `ONYX_API_KEY`
- `ONYX_PERSONA_ID`

Esos valores se obtienen/configuran dentro de Onyx. Si GENIA no recibe respuesta, revisa:

- Onyx esta arriba en `http://localhost:8080`.
- La URL `ONYX_BASE_URL` coincide con donde corre el backend.
- La API key/persona existen si tu Onyx las exige.
- El proveedor/modelo LLM dentro de Onyx esta configurado.

## Importante

Onyx no hace que todas las IAs funcionen automaticamente.

Onyx puede orquestar modelos y agentes, pero igual debes configurar proveedores/modelos dentro de Onyx o en GENIA:

- OpenAI requiere `OPENAI_API_KEY`.
- Ollama requiere servicio Ollama y modelos descargados.
- Onyx requiere su propio despliegue y configuracion.
- LiteLLM es opcional si quieres centralizar varios proveedores.

## Cambios locales de onyx-local

Si necesitas saber que diferencias locales se encontraron en `onyx-local`, revisa:

```txt
docs/onyx-local.md
```
