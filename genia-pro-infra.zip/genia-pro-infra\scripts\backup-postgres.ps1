param(
  [string]$OutputDir = "./backups",
  [string]$Service = "postgres"
)

$ErrorActionPreference = "Stop"

if (!(Test-Path $OutputDir)) {
  New-Item -ItemType Directory -Path $OutputDir | Out-Null
}

$stamp = Get-Date -Format "yyyyMMdd_HHmmss"
$fileName = "genia_pro_$stamp.dump"
$containerPath = "/backups/$fileName"

docker compose exec -T $Service sh -lc "pg_dump -U `$POSTGRES_USER -d `$POSTGRES_DB -F c -f $containerPath"

Write-Host "Backup creado: $OutputDir/$fileName"
