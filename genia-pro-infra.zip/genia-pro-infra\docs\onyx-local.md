# onyx-local

`onyx-local/` es una copia local del repositorio oficial de Onyx:

```txt
https://github.com/onyx-dot-app/onyx.git
```

No pertenece al frontend ni al backend de GENIA. Se usa como servicio externo opcional para IA.

## Estado revisado

Rama local:

```txt
main
```

Remoto:

```txt
origin https://github.com/onyx-dot-app/onyx.git
```

Ultimo commit revisado:

```txt
cd7c86e perf(craft): shrink sandbox image and prune unused deps (#11304)
```

## Cambios locales encontrados

Git mostraba varios archivos modificados por saltos de linea de Windows, pero el cambio real de contenido estaba en:

```txt
deployment/docker_compose/docker-compose.yml
```

Cambios funcionales:

1. En `web_server` se agrego:

```yaml
- HOSTNAME=0.0.0.0
```

2. En `nginx.command` se cambio la forma de ejecutar `run-nginx.sh`.

Version compatible con Windows/CRLF:

```yaml
command: >
  /bin/sh -c "rm -f /etc/nginx/conf.d/default.conf
  && cp -a /nginx-templates/. /etc/nginx/conf.d/
  && sed 's/\r$//' /etc/nginx/conf.d/run-nginx.sh > /tmp/run-nginx.sh
  && chmod +x /tmp/run-nginx.sh
  && /tmp/run-nginx.sh app.conf.template"
```

## Decision

No se recomienda subir `onyx-local` a GitHub solo por estos cambios.

En su lugar, `genia-pro-infra/scripts/start-onyx-lite.ps1` aplica/verifica estos ajustes cuando se levanta Onyx Lite.

Asi, en otro computador o VPS puedes clonar Onyx oficial:

```powershell
git clone https://github.com/onyx-dot-app/onyx.git onyx-local
```

Y luego levantarlo desde infra:

```powershell
cd genia-pro-infra
.\scripts\start-onyx-lite.ps1
```

## Si algun dia se modifica Onyx

Solo crea un repo/fork propio si vas a:

- cambiar codigo fuente de Onyx,
- personalizar su UI,
- crear conectores propios,
- congelar una version empresarial,
- mantener parches permanentes que no puedan vivir en infra.

Nombre sugerido si eso ocurre:

```txt
genia-pro-onyx
```

Por ahora no hace falta.
