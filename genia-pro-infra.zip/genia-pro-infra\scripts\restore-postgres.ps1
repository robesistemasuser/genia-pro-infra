param(
  [Parameter(Mandatory = $true)]
  [string]$BackupFile,
  [string]$Service = "postgres"
)

$ErrorActionPreference = "Stop"

if (!(Test-Path $BackupFile)) {
  throw "No existe el backup: $BackupFile"
}

$fileName = Split-Path $BackupFile -Leaf
$backupDir = Resolve-Path (Split-Path $BackupFile -Parent)
$repoBackups = Resolve-Path "./backups"

if ($backupDir.Path -ne $repoBackups.Path) {
  Copy-Item -LiteralPath $BackupFile -Destination (Join-Path $repoBackups.Path $fileName) -Force
}

$containerPath = "/backups/$fileName"

docker compose exec -T $Service sh -lc "dropdb -U `$POSTGRES_USER --if-exists `$POSTGRES_DB && createdb -U `$POSTGRES_USER `$POSTGRES_DB && pg_restore -U `$POSTGRES_USER -d `$POSTGRES_DB --clean --if-exists $containerPath"

Write-Host "Backup restaurado: $fileName"
