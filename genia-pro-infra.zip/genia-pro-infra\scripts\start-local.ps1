$ErrorActionPreference = "Stop"

if (!(Test-Path ".env")) {
  Copy-Item ".env.example" ".env"
  Write-Host "Se creo .env desde .env.example. Revisa claves y passwords antes de produccion."
}

docker compose up -d --build

Write-Host "GENIA PRO levantando:"
Write-Host "- Frontend: http://localhost:3000"
Write-Host "- Backend:  http://localhost:3001/api/docs"
