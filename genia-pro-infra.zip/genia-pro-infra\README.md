# GENIA PRO Infra

Repositorio de infraestructura para levantar GENIA PRO en otro computador, VPS o nube.

## Estructura esperada

Clona o descomprime los repos como carpetas hermanas:

```txt
GENIA_PRO/
  genia-pro-frontend/
  genia-pro-backend/
  genia-pro-infra/
```

Desde `genia-pro-infra/`, Docker Compose usa:

- `../genia-pro-frontend`
- `../genia-pro-backend`

## Arranque local con Docker

1. Copia variables:

```powershell
Copy-Item .env.example .env
```

2. Edita `.env` y cambia passwords/secrets.

3. Levanta servicios:

```powershell
.\scripts\start-local.ps1
```

O manual:

```powershell
docker compose up -d --build
```

URLs:

- Frontend: `http://localhost:3000`
- Backend Swagger: `http://localhost:3001/api/docs`
- PostgreSQL: `localhost:5432`

## Base de datos

El backend ejecuta:

```bash
npx prisma migrate deploy
```

al iniciar el contenedor.

Los datos de PostgreSQL quedan en el volumen Docker:

```txt
genia_postgres_data
```

## Archivos subidos

Los documentos subidos por la plataforma se guardan en:

```txt
genia_uploads
```

El backend expone esos archivos por:

```txt
/uploads/...
```

La base solo guarda la ruta y metadata, no el archivo completo.

## Backup

Crear backup:

```powershell
.\scripts\backup-postgres.ps1
```

Restaurar backup:

```powershell
.\scripts\restore-postgres.ps1 -BackupFile .\backups\genia_pro_YYYYMMDD_HHMMSS.dump
```

No subas backups reales a GitHub si contienen clientes, usuarios, contratos o datos sensibles.

## onyx-local

`onyx-local` no pertenece al frontend ni al backend. Es un servicio externo opcional de IA/busqueda local.

Recomendacion:

- mantenerlo como repo externo,
- levantarlo desde `genia-pro-infra` solo cuando se necesite,
- conectar el backend GENIA usando variables `ONYX_*`.

No lo mezcles dentro de los repos `genia-pro-frontend` ni `genia-pro-backend`.

Levantar Onyx Lite:

```powershell
.\scripts\start-onyx-lite.ps1
```

Detener Onyx Lite:

```powershell
.\scripts\stop-onyx-lite.ps1
```

Levantar GENIA con configuracion Onyx:

```powershell
docker compose -f docker-compose.yml -f docker-compose.onyx.yml up -d --build
```

Mas detalle:

```txt
docs/onyx.md
docs/onyx-local.md
```

## Produccion

Antes de produccion:

- Cambiar `POSTGRES_PASSWORD`.
- Cambiar `JWT_SECRET` y `JWT_REFRESH_SECRET`.
- Configurar `CORS_ORIGIN` con el dominio real.
- Usar HTTPS con Nginx, Traefik, Cloudflare o proxy equivalente.
- Programar backups automaticos.
- Revisar almacenamiento persistente para `genia_uploads`.
