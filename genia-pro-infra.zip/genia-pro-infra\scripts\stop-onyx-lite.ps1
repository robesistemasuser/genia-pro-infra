param(
  [string]$OnyxPath = "../onyx-local/deployment/docker_compose"
)

$ErrorActionPreference = "Stop"

$onyxComposeDir = Resolve-Path $OnyxPath

Push-Location $onyxComposeDir
try {
  docker compose -f docker-compose.yml -f docker-compose.onyx-lite.yml down
} finally {
  Pop-Location
}

Write-Host "Onyx Lite detenido."
